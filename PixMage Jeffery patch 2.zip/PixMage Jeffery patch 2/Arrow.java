class Arrow extends Projectile{
  Arrow(int spawnX, int spawnY, int targetX, int targetY){
    super(spawnX, spawnY, 8, targetX, targetY, 8, 10, 10);
  }
}