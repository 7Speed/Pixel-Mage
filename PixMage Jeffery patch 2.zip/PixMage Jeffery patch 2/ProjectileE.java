/**
 * Auto Generated Java Class.
 */
import java.awt.Rectangle;
import java.util.ArrayList;

public class ProjectileE extends Enemy{
  int reload;
  int range;
  
  private ArrayList<Projectile> projectiles = new ArrayList<Projectile>();
  
  public ProjectileE (int health, int aggro, int x, int y) { 
    super(health, aggro, x, y);
  }
  
  public void fire(int spawnX, int spawnY, int targetX, int targetY){
    EnemyProjectile errow = new EnemyProjectile(spawnX, spawnY, targetX, targetY);
    addProjectile(errow);
  }
  
  public void addProjectile(Projectile projectile){
    projectiles.add(projectile);
  }
  
  public ArrayList<Projectile> getProjectiles(){
    return projectiles;
  }
  
  public int getReload(){
    return reload; 
  }
  
  public void addReload(){
    this.reload = this.reload + 1; 
  }
  
  public void wipeReload(){
    this.reload = 0; 
  }
  
  public int getRange(int playerX, int playerY){
    int a;
    int b;
    
    a = (super.getX()+ super.getSize()/2) - playerX;
    b = (super.getY()+ super.getSize()/2) - playerY;
    
    this.range = (int)(Math.sqrt(a*a + b*b));
    return range;
  }
}//class

  

