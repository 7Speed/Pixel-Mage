/**
 * Auto Generated Java Class.
 */
class EnemyProjectile extends Projectile {
  public EnemyProjectile(int spawnX, int spawnY, int targetX, int targetY){ 
    super(spawnX, spawnY, 8, targetX, targetY, 8, 10, 10);
  }
  /* ADD YOUR CODE HERE */
  
}
